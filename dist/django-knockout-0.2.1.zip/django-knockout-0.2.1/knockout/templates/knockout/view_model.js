{% load knockout_tags %}

{{ model_string }}
var {{ view_model_string }} = function(data) {
    var self = this;
	{{ model_list_string }}
} // {{ view_model_string }}
