
var {{ model_data_string }} = {{ data|safe }}; // Escaped in view
